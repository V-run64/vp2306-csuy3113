//
//  File 3.cpp
//  SDLProject
//
//  Created by Varun Pandian on 4/7/25.
//  Copyright © 2025 ctg. All rights reserved.
//


    m_font_texture_id = Utility::load_texture("assets/font1.png");
