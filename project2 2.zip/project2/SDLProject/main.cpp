/**
* Author: Varun Pandian
* Assignment: Pong Clone
* Date due: 2025-3-01, 11:59pm
* I pledge that I have completed this assignment without
* collaborating with anyone else, in conformance with the
* NYU School of Engineering Policies and Procedures on
* Academic Misconduct.
**/


#define GL_SILENCE_DEPRECATION
#define STB_IMAGE_IMPLEMENTATION
#define LOG(argument) std::cout << argument << '\n'
#ifdef _WINDOWS
#include <GL/glew.h>
#endif
#define GL_GLEXT_PROTOTYPES 1
#include <SDL.h>
#include <SDL_opengl.h>
#include "glm/mat4x4.hpp"
#include "glm/gtc/matrix_transform.hpp"
#include "ShaderProgram.h"
#include "stb_image.h"
#include "cmath"
#include <ctime>
enum AppStatus { RUNNING, TERMINATED };
constexpr float WINDOW_SIZE_MULT = 2.0f;
constexpr int WINDOW_WIDTH = 640 * 1.5,
       WINDOW_HEIGHT = 480 * 1.5;
constexpr float BG_RED   = 1.0f,
        BG_GREEN  = 1.0f,
        BG_BLUE  = 1.0f,
        BG_OPACITY = 1.0f;
constexpr int VIEWPORT_X = 0,
     VIEWPORT_Y = 0,
     VIEWPORT_WIDTH = WINDOW_WIDTH,
     VIEWPORT_HEIGHT = WINDOW_HEIGHT;
constexpr char V_SHADER_PATH[] = "shaders/vertex_textured.glsl",
      F_SHADER_PATH[] = "shaders/fragment_textured.glsl";
constexpr GLint NUMBER_OF_TEXTURES = 1;
constexpr GLint LEVEL_OF_DETAIL  = 0;
constexpr GLint TEXTURE_BORDER   = 0;
constexpr float MILLISECONDS_IN_SECOND = 1000.0;
constexpr char
        THING_SPRITE_FILEPATH[] = "butheresthething.png",
        HULK_SPRITE_FILEPATH[] = "hulk.png",
        LOGAN_SPRITE_FILEPATH[] = "wolvy.png",
        HULKWIN_SPRITE_FILEPATH[] = "hulksmash.png",
        THINGWIN_SPRITE_FILEPATH[] = "clobberintime.png",
        LOGAN2_SPRITE_FILEPATH[] = "maroon5.png",
        WOLVERINE_SPRITE_FILEPATH[] = "wolverine.png";

        

constexpr float MINIMUM_COLLISION_DISTANCE = 1.0f;
constexpr glm::vec3
          INIT_POS_THING = glm::vec3(-3.0f, 0.0f, 0.0f),
          INIT_SCALE_THING= glm::vec3(2.5f, 2.5f, 0.0f),
          INIT_POS_HULK= glm::vec3(3.0f, 0.0f, 0.0f),
          INIT_SCALE_HULK = glm::vec3(2.5f, 2.5f, 0.0f),
          INIT_POS_LOGAN = glm::vec3(0.0f, 0.0f, 0.0f),
          INIT_SCALE_LOGAN = glm::vec3(2.0f, 2.0f, 0.0f),
          INIT_POS_LOGAN2 = glm::vec3(0.0f, 1.0f, 0.0f),
          INIT_SCALE_LOGAN2 = glm::vec3(2.0f, 2.0f, 0.0f),
          INIT_POS_THINGWIN = glm::vec3(0.0f, 0.0f, 0.0f),
          INIT_SCALE_THINGWIN = glm::vec3(5.0f, 5.0f, 5.0f),
          INIT_POS_HULKWIN = glm::vec3(0.0f, 0.0f, 0.0f),
          INIT_SCALE_HULKWIN = glm::vec3(5.0f, 5.0f, 5.0f),
          INIT_POS_WOLVERINE = glm::vec3(0.0f, -1.0f, 0.0f),
          INIT_SCALE_WOLVERINE = glm::vec3(2.0f, 2.0f, 0.0f);
            
          
bool is_single_player = false;
bool game_started = false;
bool hulkwins = false;
bool thingwins = false;
int ball_count = 1;
bool g_logan2_active = false;
bool g_wolverine_active = false;


//for balls 1(logan), 2(logan2), and 3(wolverine
struct Ball {
    glm::vec3 position;
    glm::vec3 movement;
    GLuint texture_id;
};

std::vector<Ball> balls;

SDL_Window* g_display_window;
AppStatus g_app_status = RUNNING;
ShaderProgram g_shader_program = ShaderProgram();
glm::mat4 g_view_matrix, g_projection_matrix, g_thing_matrix, g_hulk_matrix, g_thingwin_matrix, g_hulkwin_matrix, g_logan_matrix, g_logan2_matrix, g_wolverine_matrix;
float g_previous_ticks = 0.0f;
GLuint g_thing_texture_id;
GLuint g_hulk_texture_id;
GLuint g_logan_texture_id;
GLuint g_thingwin_texture_id;
GLuint g_hulkwin_texture_id;
GLuint g_logan2_texture_id;
GLuint g_wolverine_texture_id;
constexpr float THING_SPEED = 3.0f;
const float BALL_SPEED = 2.0f;
float fastball_boundary = 3.0f;


glm::vec3 g_thing_movement = glm::vec3(0.0f, 0.0f, 0.0f);
glm::vec3 g_thing_position = glm::vec3(0.0f, 0.0f, 0.0f);
glm::vec3 g_hulk_movement = glm::vec3(0.0f, 0.0f, 0.0f);
glm::vec3 g_hulk_position = glm::vec3(0.0f, 0.0f, 0.0f);
glm::vec3 g_logan_movement = glm::vec3(1.0f, 1.0f, 0.0f);
glm::vec3 g_logan_position = glm::vec3(0.0f, 0.0f, 0.0f);
glm::vec3 g_logan_scale = glm::vec3(0.0f, 0.0f, 0.0f);
glm::vec3 g_logan_size = glm::vec3(0.0f, 0.0f, 0.0f);
glm::vec3 g_logan2_scale = glm::vec3(0.0f, 0.0f, 0.0f);
glm::vec3 g_wolverine_size = glm::vec3(0.0f, 0.0f, 0.0f);


float thing_width = 1.0f * INIT_SCALE_THING.x;
float thing_height = 1.0f * INIT_SCALE_THING.y;
float hulk_width = 1.0f * INIT_SCALE_HULK.x;
float hulk_height = 1.0f * INIT_SCALE_HULK.y;
float logan_width = 1.0f * INIT_SCALE_LOGAN.x;
float logan_height = 1.0f * INIT_SCALE_LOGAN.y;
float logan2_width = 1.0f * INIT_SCALE_LOGAN2.x;
float logan2_height = 1.0f * INIT_SCALE_LOGAN2.y;
float wolverine_width = 1.0f * INIT_SCALE_WOLVERINE.x;
float wolverine_height = 1.0f * INIT_SCALE_WOLVERINE.y;







void initialise();
void process_input();
void update();
void render();
void shutdown();
GLuint load_texture(const char* filepath)
{
  // STEP 1: Loading the image file
  int width, height, number_of_components;
  unsigned char* image = stbi_load(filepath, &width, &height, &number_of_components, STBI_rgb_alpha);
  if (image == NULL)
  {
    LOG("Unable to load image. Make sure the path is correct.");
    assert(false);
  }
  // STEP 2: Generating and binding a texture ID to our image
  GLuint textureID;
  glGenTextures(NUMBER_OF_TEXTURES, &textureID);
  glBindTexture(GL_TEXTURE_2D, textureID);
  glTexImage2D(GL_TEXTURE_2D, LEVEL_OF_DETAIL, GL_RGBA, width, height, TEXTURE_BORDER, GL_RGBA, GL_UNSIGNED_BYTE, image);
  // STEP 3: Setting our texture filter parameters
  glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_NEAREST);
  glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_NEAREST);
  // STEP 4: Releasing our file from memory and returning our texture id
  stbi_image_free(image);
  return textureID;
}
void initialise()
{
  SDL_Init(SDL_INIT_VIDEO);
  g_display_window = SDL_CreateWindow("Thing Pong: Fastball Special",
                   SDL_WINDOWPOS_CENTERED, SDL_WINDOWPOS_CENTERED,
                   WINDOW_WIDTH, WINDOW_HEIGHT,
                   SDL_WINDOW_OPENGL);
  SDL_GLContext context = SDL_GL_CreateContext(g_display_window);
  SDL_GL_MakeCurrent(g_display_window, context);
  if (g_display_window == nullptr) shutdown();
#ifdef _WINDOWS
  glewInit();
#endif
  glViewport(VIEWPORT_X, VIEWPORT_Y, VIEWPORT_WIDTH, VIEWPORT_HEIGHT);
  g_shader_program.load(V_SHADER_PATH, F_SHADER_PATH);
  g_view_matrix = glm::mat4(1.0f);
  g_projection_matrix = glm::ortho(-5.0f, 5.0f, -3.75f, 3.75f, -1.0f, 1.0f);
  g_shader_program.set_projection_matrix(g_projection_matrix);
  g_shader_program.set_view_matrix(g_view_matrix);
  glUseProgram(g_shader_program.get_program_id());
  glClearColor(BG_RED, BG_BLUE, BG_GREEN, BG_OPACITY);
  g_thing_texture_id = load_texture(THING_SPRITE_FILEPATH);
  g_hulk_texture_id = load_texture(HULK_SPRITE_FILEPATH);
  g_logan_texture_id = load_texture(LOGAN_SPRITE_FILEPATH);
  g_logan2_texture_id = load_texture(LOGAN2_SPRITE_FILEPATH);
  g_wolverine_texture_id = load_texture(WOLVERINE_SPRITE_FILEPATH);
  g_thingwin_texture_id = load_texture(THINGWIN_SPRITE_FILEPATH);
  g_hulkwin_texture_id = load_texture(HULKWIN_SPRITE_FILEPATH);

  // enable blending
  glEnable(GL_BLEND);
  glBlendFunc(GL_SRC_ALPHA, GL_ONE_MINUS_SRC_ALPHA);
}

bool did_collide(glm::vec3 logan_position, glm::vec3 paddle_position, std::string paddlechar)
{
    float logan_x = g_logan_position.x;
    float paddle_x;
    float logan_y = g_logan_position.y;
    float paddle_y;
    float logan_width = INIT_SCALE_LOGAN.x;
    float paddle_width;
    float logan_height = INIT_SCALE_LOGAN.y;
    float paddle_height;
    
    
    if(paddlechar == "thing")
    {
        paddle_x = g_thing_position.x + INIT_POS_THING.x;
        paddle_y = g_thing_position.y + INIT_POS_THING.y;
        paddle_width = INIT_SCALE_THING.x;
        paddle_height = INIT_SCALE_THING.y;
        
        
        std::cout << "Collision detected: Ball hit Thing's paddle!" << std::endl;
        
    }
    else if(paddlechar == "hulk")
    {
        paddle_x = g_hulk_position.x + INIT_POS_HULK.x;
        paddle_y = g_hulk_position.y + INIT_POS_HULK.y;
        paddle_width = INIT_SCALE_HULK.x;
        paddle_height = INIT_SCALE_HULK.y;
        
        std::cout << "Collision detected: Ball hit Hulk's paddle!" << std::endl;
    }
    
    float delta_x = fabs(paddle_x - logan_x);
    float distance_x = delta_x - ((logan_width + paddle_width)/5);
    
    float delta_y = fabs(paddle_y - logan_y);
    float distance_y = delta_y - ((logan_height + paddle_height)/3.25);
    
    
    return ((distance_x <=0) && (distance_y <=0));
}

void process_input()
{
  g_thing_movement.y = 0;
    
  g_hulk_movement.y = 0;
  if (glm::length(g_logan_movement) == 0.0f) {
        g_logan_movement = glm::vec3(1.0f, 1.0f, 0.0f); // Reset only if stopped
    }
  SDL_Event event;
  while (SDL_PollEvent(&event))
  {
    switch (event.type)
    {
      // End game
      case SDL_QUIT:
      case SDL_WINDOWEVENT_CLOSE:
        g_app_status = TERMINATED;
        break;
      case SDL_KEYDOWN:
        switch (event.key.keysym.sym)
        {
          case SDLK_q: g_app_status = TERMINATED; break;
            case SDLK_t:
                is_single_player = !is_single_player;
            case SDLK_1:
                ball_count = 1;
            case SDLK_2:
                ball_count = 2;
            case SDLK_3:
                ball_count = 3;
            
                
          default: break;
        }
      default:
        break;
    }
  }
  const Uint8 *key_state = SDL_GetKeyboardState(NULL);
    
    //thing movement, will always be controllable
    if (key_state[SDL_SCANCODE_W] && g_thing_position.y + THING_SPEED <= 4.5f){g_thing_movement.y = 0.5;
        game_started = true; }
    else if (key_state[SDL_SCANCODE_S]  && g_thing_position.y - THING_SPEED >= -4.5f){g_thing_movement.y = -0.5;
        game_started = true; }
    
    //hulk movement if two players

    
    static bool moving_up = true;
    if (is_single_player) {
        if (moving_up) {
            g_hulk_movement.y = 0.5f;
            if (g_hulk_position.y + (INIT_SCALE_HULK.y) >= 4.0f) {
                moving_up = false;
            }
        } else {
            g_hulk_movement.y = -0.5f; 
            if (g_hulk_position.y - (INIT_SCALE_HULK.y) <= -4.0f) {
                moving_up = true;
            }
        }
    }
    else if (!is_single_player)
    {
        if(key_state[SDL_SCANCODE_UP] && g_hulk_position.y + THING_SPEED <= 4.5f) {g_hulk_movement.y = 0.5;
            game_started = true; }
        else if (key_state[SDL_SCANCODE_DOWN] && g_hulk_position.y - THING_SPEED >= -4.5f) {g_hulk_movement.y = -0.5;
            game_started = true; }
    }

    
    else{
        if(g_hulk_position.y + THING_SPEED <= 4.25f)
        {g_hulk_movement.y = 0.5;}
        else if (g_hulk_position.y - THING_SPEED >= -4.5f)
        {g_hulk_movement.y = -0.5;}
            
        
    }
    

    
}
void update() {
    
    // INITIALIZE //
    g_thing_matrix = glm::mat4(1.0f);
    g_hulk_matrix = glm::mat4(1.0f);
    g_logan_matrix = glm::mat4(1.0f);
    
    g_thing_matrix = glm::translate(g_thing_matrix, INIT_POS_THING);
    g_hulk_matrix = glm::translate(g_hulk_matrix, INIT_POS_HULK);
    g_logan_matrix = glm::translate(g_logan_matrix, INIT_POS_LOGAN);

    
    
    g_thing_matrix = glm::scale(g_thing_matrix, INIT_SCALE_THING);
    

    g_hulk_matrix = glm::scale(g_hulk_matrix, INIT_SCALE_HULK);
    
   
  
    // --- DELTA TIME CALCULATIONS --- //
    float ticks = (float) SDL_GetTicks() / MILLISECONDS_IN_SECOND;
    float delta_time = ticks - g_previous_ticks;
    g_previous_ticks = ticks;
    
    // --- ACCUMULATOR LOGIC --- //
    g_thing_position += g_thing_movement * THING_SPEED * delta_time;
    g_hulk_position += g_hulk_movement * THING_SPEED * delta_time;
    // --- TRANSLATION --- //
    g_thing_matrix = glm::translate(g_thing_matrix, g_thing_position);
    g_hulk_matrix = glm::translate(g_hulk_matrix, g_hulk_position);
    if (game_started) {
        g_logan_position += g_logan_movement * BALL_SPEED * delta_time;
    }
    g_logan_matrix = glm::translate(g_logan_matrix, g_logan_position);
    // --- COLLISION LOGIC --- //
    

    //Logan Hits Ceiling
    if (g_logan_position.y + (logan_height / 2.0f) >= 4.5f ||
        g_logan_position.y - (logan_height / 2.0f) <= -4.5f) {
        g_logan_movement.y = -g_logan_movement.y;
    }
    
    if(did_collide(g_logan_position, g_thing_position, "thing"))
    {
        g_logan_movement.x = 1.0;
        
    }
    
    if(did_collide(g_logan_position, g_hulk_position, "hulk"))
    {
        g_logan_movement.x = -1.0;
        
    }

 
    // Ensure Thing stays within vertical bounds
       if (g_thing_position.y + (INIT_SCALE_THING.y / 2.0f) > 3.75f) {
           g_thing_position.y = 3.75f - (INIT_SCALE_THING.y / 4.0f);
       } else if (g_thing_position.y - (INIT_SCALE_THING.y / 4.0f) < -3.75f) {
           g_thing_position.y = -3.75f + (INIT_SCALE_THING.y / 2.0f);
       }

       // Ensure Hulk stays within vertical bounds
       if (g_hulk_position.y + (INIT_SCALE_HULK.y / 2.0f) > 3.75f) {
           g_hulk_position.y = 3.75f - (INIT_SCALE_HULK.y / 2.0f);
       } else if (g_hulk_position.y - (INIT_SCALE_HULK.y / 2.0f) < -3.75f) {
           g_hulk_position.y = -3.75f + (INIT_SCALE_HULK.y / 2.0f);
       }


    // Check if the ball goes out of bounds (game over)
    //hulk wins
    if (g_logan_position.x < -5.0f) {
        g_logan_position = INIT_POS_LOGAN; // Reset ball position
        g_logan_movement = glm::vec3(1.0f, 1.0f, 0.0f); // Reset movement
        game_started = false; // Stop movement until the next round
        hulkwins = true;
        thingwins = false;
        
    }
    
    //thing wins
    else if(g_logan_position.x > 5.0f)
    {
        g_logan_position = INIT_POS_LOGAN; // Reset ball position
        g_logan_movement = glm::vec3(1.0f, 1.0f, 0.0f); // Reset movement
        game_started = false; // Stop movement until the next round
        thingwins = true;
        hulkwins = false;
    }
    
    if (is_single_player) {
            if (g_hulk_position.y >= 3.75f) {
                g_hulk_position.y -= THING_SPEED; // Move down
            } else if (g_hulk_position.y <= -3.75f) {
                g_hulk_position.y += THING_SPEED; // Move up
            }
        }
}
void draw_object(glm::mat4 &object_model_matrix, GLuint &object_texture_id)
{
  g_shader_program.set_model_matrix(object_model_matrix);
  glBindTexture(GL_TEXTURE_2D, object_texture_id);
  glDrawArrays(GL_TRIANGLES, 0, 6); // we are now drawing 2 triangles, so we use 6 instead of 3
}
void render() {
  glClear(GL_COLOR_BUFFER_BIT);
  // Vertices
  float vertices[] = {
    -0.5f, -0.5f, 0.5f, -0.5f, 0.5f, 0.5f, // triangle 1
    -0.5f, -0.5f, 0.5f, 0.5f, -0.5f, 0.5f  // triangle 2
  };
  // Textures
  float texture_coordinates[] = {
    0.0f, 1.0f, 1.0f, 1.0f, 1.0f, 0.0f,   // triangle 1
    0.0f, 1.0f, 1.0f, 0.0f, 0.0f, 0.0f,   // triangle 2
  };
  glVertexAttribPointer(g_shader_program.get_position_attribute(), 2, GL_FLOAT, false, 0, vertices);
  glEnableVertexAttribArray(g_shader_program.get_position_attribute());
  glVertexAttribPointer(g_shader_program.get_tex_coordinate_attribute(), 2, GL_FLOAT, false, 0, texture_coordinates);
  glEnableVertexAttribArray(g_shader_program.get_tex_coordinate_attribute());
  // Bind texture
  draw_object(g_logan_matrix, g_logan_texture_id);
  draw_object(g_thing_matrix, g_thing_texture_id);
  draw_object(g_hulk_matrix,g_hulk_texture_id);
 
    if (game_started) {
        hulkwins = false;
        thingwins = false;
        
    }
    
    if(thingwins)
    {
        g_thingwin_matrix = glm::mat4(1.0f);
        g_thingwin_matrix = glm::translate(g_thingwin_matrix, INIT_POS_THINGWIN);
        g_thingwin_matrix = glm::scale(g_thingwin_matrix, INIT_SCALE_THINGWIN);
        draw_object(g_thingwin_matrix, g_thingwin_texture_id);

    }
    
    if(hulkwins)
    {
        g_hulkwin_matrix = glm::mat4(1.0f);
        g_hulkwin_matrix = glm::translate(g_hulkwin_matrix, INIT_POS_HULKWIN);
        g_hulkwin_matrix = glm::scale(g_hulkwin_matrix, INIT_SCALE_HULKWIN);
        draw_object(g_hulkwin_matrix, g_hulkwin_texture_id);

    }
    
    if(ball_count == 2 && game_started)
    {
        g_logan2_matrix = glm::mat4(1.0f);
        g_logan2_matrix = glm::translate(g_logan2_matrix, INIT_POS_LOGAN2);
        g_hulkwin_matrix = glm::scale(g_hulkwin_matrix, INIT_SCALE_HULKWIN);
        draw_object(g_logan2_matrix, g_logan2_texture_id);
    }
  // We disable two attribute arrays now
  glDisableVertexAttribArray(g_shader_program.get_position_attribute());
  glDisableVertexAttribArray(g_shader_program.get_tex_coordinate_attribute());
  SDL_GL_SwapWindow(g_display_window);
}
void shutdown() { SDL_Quit(); }
int main(int argc, char* argv[])
{
  initialise();
  while (g_app_status == RUNNING)
  {
    process_input();
    update();
    render();
  }
  shutdown();
  return 0;
}


