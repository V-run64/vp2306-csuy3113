    m_font_texture_id = Utility::load_texture("assets/font1.png");
