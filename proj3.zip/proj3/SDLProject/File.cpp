//
//  File.cpp
//  SDLProject
//
//  Created by Varun Pandian on 3/18/25.
//  Copyright © 2025 ctg. All rights reserved.
//


#include <SDL.h>
#include <SDL_opengl.h>
#include <SDL_mixer.h>
#include "glm/mat4x4.hpp"
#include "glm/gtc/matrix_transform.hpp"
#include "ShaderProgram.h"
#include "stb_image.h"
#include "cmath"
#include <ctime>
#include <vector>
#include <cstdlib>
#include "Entity.h"
